#AREEBA
#SU91-BIETM-F23-038
import os
import random
import time
import requests
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
# Function to get a random user agent
def get_random_user_agent():
    ua = UserAgent()
    return ua.random
# Initialize the Chrome driver with WebDriver Manager and random user agent
options = webdriver.ChromeOptions()
options.add_argument(f"user-agent={get_random_user_agent()}")
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
url = "https://www.tripadvisor.com/Hotels"
# Open the URL with Selenium
driver.get(url)
# Random delay to mimic human behavior
time.sleep(random.randint(5, 10))
# Get the page source after JS execution
html_content = driver.page_source
# Close the browser
driver.quit()
soup = BeautifulSoup(html_content, 'html.parser')
print(soup.prettify())

# Initialize lists to store extracted data
images = []
text_contents = []
links = []
headings = []

# Extract images (src attribute of img tags)
for img in soup.find_all('img'):
    src = img.get('src')
    if src and src.startswith('http'):
        images.append(src)

# Extract text content (p tags and others as needed)
for element in soup.find_all(['p', 'span', 'div']):
    text = element.get_text(strip=True)
    if text:
        text_contents.append(text)

# Extract links (href attribute of a tags)
for a in soup.find_all('a', href=True):
    href = a['href']
    if href.startswith('http'):
        links.append(href)

# Extract headings (h1 to h6 tags)
for heading in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
    headings.append(heading.get_text(strip=True))

# Print all extracted data on the terminal
print("\nExtracted Images:")
for img in images:
    print(img)

print("\nExtracted Text Content:")
for content in text_contents:
    print(content)

print("\nExtracted Links:")
for link in links:
    print(link)

print("\nExtracted Headings:")
for heading in headings:
    print(heading)

# Create directories for each content type
directories = ['images', 'text', 'links', 'headings']
for directory in directories:
    if not os.path.exists(directory):
        os.makedirs(directory)

# Save images
for i, img_url in enumerate(images):
    try:
        img_response = requests.get(img_url)
        img_response.raise_for_status()
        with open(f'images/image_{i}.jpg', 'wb') as f:
            f.write(img_response.content)
    except requests.exceptions.RequestException as e:
        print(f"Error downloading image {img_url}: {e}")

# Save text content
with open('text/content.txt', 'w', encoding='utf-8') as f:
    for content in text_contents:
        f.write(content + '\n')

# Save links
with open('links/links.txt', 'w', encoding='utf-8') as f:
    for link in links:
        f.write(link + '\n')

# Save headings
with open('headings/headings.txt', 'w', encoding='utf-8') as f:
    for heading in headings:
        f.write(heading + '\n')

print("Data extracted and saved successfully!")


