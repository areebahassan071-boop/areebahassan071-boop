// =====================================================
//  UI ELEMENTS
// =====================================================
const uploadBtn = document.getElementById("uploadBtn");
const fileInput = document.getElementById("fileInput");
const autoBtn = document.getElementById("autoBtn");
const stepBtn = document.getElementById("stepBtn");
const intervalInput = document.getElementById("interval");
const csvBtn = document.getElementById("csvBtn");
const pdfBtn = document.getElementById("pdfBtn");

let lastGanttLength = 0;
let loading = false;

// =====================================================
//  SMALL HELPER FOR SMOOTH ALERTS
// =====================================================
function notify(msg, type = "info") {
    const box = document.createElement("div");
    box.className = `toast toast-${type}`;
    box.innerText = msg;

    Object.assign(box.style, {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        background: type === "error" ? "#ff4d4d" : "#0077cc",
        color: "white",
        padding: "10px 16px",
        borderRadius: "6px",
        fontWeight: "bold",
        boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
        zIndex: 9999,
        opacity: 0,
        transition: "0.4s",
    });

    document.body.appendChild(box);

    setTimeout(() => (box.style.opacity = 1), 20);
    setTimeout(() => {
        box.style.opacity = 0;
        setTimeout(() => box.remove(), 300);
    }, 2000);
}

// =====================================================
//  UPLOAD HANDLER
// =====================================================
uploadBtn.addEventListener("click", async () => {
    const file = fileInput.files[0];
    if (!file) return notify("Select a file first", "error");

    const formData = new FormData();
    formData.append("file", file);

    try {
        const res = await fetch("/upload", { method: "POST", body: formData });
        const data = await res.json();

        if (!data.ok) return notify(data.error || "Upload failed", "error");

        notify("Process Uploaded Successfully!", "info");
        loadState();
    } catch (err) {
        notify("Upload error", "error");
    }
});

// =====================================================
//  STEP BUTTON
// =====================================================
stepBtn.addEventListener("click", async () => {
    await fetch("/step", { method: "POST" });
    loadState();
});

// =====================================================
//  AUTO MODE
// =====================================================
autoBtn.addEventListener("click", async () => {
    const mode = autoBtn.dataset.mode;
    const interval = intervalInput.value || 500;

    await fetch("/auto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: mode, interval }),
    });

    if (mode === "start") {
        autoBtn.innerText = "Stop Auto";
        autoBtn.dataset.mode = "stop";
        notify("Auto mode started");
    } else {
        autoBtn.innerText = "Start Auto";
        autoBtn.dataset.mode = "start";
        notify("Auto mode stopped", "error");
    }
});

// =====================================================
//  CSV / PDF EXPORT
// =====================================================
csvBtn.addEventListener("click", () => {
    window.open("/export/csv", "_blank");
});

pdfBtn.addEventListener("click", () => {
    window.open("/export/pdf", "_blank");
});

// =====================================================
//  LOAD STATE (MAIN FUNCTION)
// =====================================================
async function loadState() {
    if (loading) return;
    loading = true;

    try {
        const res = await fetch("/state");
        const data = await res.json();

        updateProcessTable(data.process_list);
        updateCPU(data.current);
        updateQueues(data.ready_queue, data.blocked_queue);
        updateGantt(data.gantt, data.current);
        updateMetrics(data.cpu_util, data.throughput);
        await loadHistory();

        // Auto-stop safeguard
        if (!data.current && !data.ready_queue.length && !data.blocked_queue.length) {
            autoBtn.innerText = "Start Auto";
            autoBtn.dataset.mode = "start";
        }
    } catch (err) {
        console.log("State update failed:", err);
    }

    loading = false;
}

// =====================================================
//  UPDATE: PROCESS TABLE
// =====================================================
function updateProcessTable(list) {
    const body = document.querySelector("#processTable tbody");
    body.innerHTML = "";

    list.forEach(p => {
        body.innerHTML += `
        <tr>
            <td>${p.pid}</td>
            <td>${p.burst}</td>
            <td>${p.arrival}</td>
            <td>${p.priority}</td>
            <td>${p.pc}</td>
            <td>${p.sp}</td>
            <td>${p.waiting_time}</td>
            <td>${p.turnaround_time}</td>
            <td>${p.state}</td>
        </tr>`;
    });
}

// =====================================================
//  UPDATE: CPU
// =====================================================
function updateCPU(current) {
    document.getElementById("current").innerText = current || "None";
}

// =====================================================
//  UPDATE: READY + BLOCKED QUEUES
// =====================================================
function updateQueues(ready, blocked) {
    const rq = document.getElementById("readyQueue");
    const bq = document.getElementById("blockedQueue");

    rq.innerHTML = "";
    ready.forEach(pid => {
        rq.innerHTML += `<span class="procBox">${pid}</span>`;
    });

    bq.innerHTML = "";
    blocked.forEach(pid => {
        bq.innerHTML += `<span class="procBox" style="background:#ff6b6b">${pid}</span>`;
    });
}

// =====================================================
//  UPDATE: GANTT CHART
// =====================================================
function updateGantt(gantt, current) {
    const ganttEl = document.getElementById("gantt");

    for (let i = lastGanttLength; i < gantt.length; i++) {
        const g = gantt[i];

        const block = document.createElement("div");
        block.className = "ganttBlock";
        block.style.background = g.color;
        block.innerText = g.pid;

        if (g.pid === current) block.style.border = "2px solid gold";

        ganttEl.appendChild(block);
        block.style.opacity = 0;
        block.style.transform = "translateY(-10px) scale(0.9)";

        setTimeout(() => {
            block.style.transition = "0.35s";
            block.style.opacity = 1;
            block.style.transform = "translateY(0px) scale(1)";
        }, 40);
    }

    lastGanttLength = gantt.length;
    ganttEl.scrollLeft = ganttEl.scrollWidth;
}

// =====================================================
//  UPDATE: HISTORY TABLE
// =====================================================
async function loadHistory() {
    const res = await fetch("/history");
    const history = await res.json();

    const body = document.querySelector("#historyTable tbody");
    body.innerHTML = "";

    history.forEach(h => {
        body.innerHTML += `
        <tr>
            <td>${h.time}</td>
            <td>${h.current}</td>
            <td>${h.state}</td>
            <td>${h.pc}</td>
            <td>${h.sp}</td>
            <td>${h.ready_queue.join(", ")}</td>
            <td>${h.blocked_queue.join(", ")}</td>
            <td>${h.cpu_util ?? 0}%</td>
            <td>${h.throughput ?? 0}</td>
        </tr>`;
    });
}

// =====================================================
//  UPDATE: METRICS
// =====================================================
function updateMetrics(cpu, throughput) {
    document.getElementById("cpuUtil").innerText = cpu + "%";
    document.getElementById("throughput").innerText = throughput;
}

// =====================================================
//  AUTO REFRESH EVERY 500MS
// =====================================================
setInterval(loadState, 500);
window.onload = () => loadState();